﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ProductCreate();
        }

        private void Form1_Load(object sender, EventArgs e)
        { }
        private void ProductCreate()

        {
            flowLayoutPanel1.Controls.Clear(); //- очищаем панель от элементов.

            using (var conn = new SqlConnection(Class1.ConnectionString)) //создаём метод и подключаем нашу базу
            {
                conn.Open(); //открываем соединение с базой

                // Получаем всех партнёров
                var productCmd = new SqlCommand("SELECT * FROM Продукция", conn); //собираем информацию из базы
                var reader = productCmd.ExecuteReader(); //считываем информацию
                var products = new List<dynamic>(); //создаём список который будет принимать данные

                while (reader.Read()) //создаём цикл на ввод данных в список
                {
                    products.Add(new
                    {
                        Name = reader["Наименование_продукции"].ToString(),
                        Type = reader["Тип_продукции"].ToString(),
                        Articul = reader["Артикул"].ToString(),
                        Price = reader["Минимальная_стоимость_для_партнера"].ToString(),
                        Material = reader["Основной_материал"].ToString()
                    });
                }

                reader.Close();//закрываем чтение

                foreach (var product in products)
                {
                    // Получаем время изготовления товара
                    var timeCmd = new SqlCommand("SELECT SUM([Время_изготовления]) FROM Цеха_с_продукцией WHERE ([Наименование_продукции]) = @id", conn);
                    timeCmd.Parameters.AddWithValue("@id", product.Name);
                    var totalObj = timeCmd.ExecuteScalar();
                    int totalQty = totalObj != DBNull.Value ? Convert.ToInt32(totalObj) : 0;

                    int time = GetTimeForProduct(totalQty);

                    // Создаём карточку
                    Panel card = new Panel
                    {
                        BorderStyle = BorderStyle.FixedSingle,
                        Width = 600,
                        Height = 100,
                        Margin = new Padding(10)
                    };

                    Label lblTitle = new Label
                    {
                        Text = $"{product.Type} | {product.Name}",
                        Font = new Font("Segoe UI", 10, FontStyle.Bold),
                        Location = new Point(10, 10),
                        AutoSize = true
                    };

                    Label lblArt = new Label
                    {
                        Text = $"Артикул: {product.Articul}",
                        Location = new Point(10, 35),
                        AutoSize = true
                    };

                    Label lblPrice = new Label
                    {
                        Text = $"Минимальная цена для партнера:{product.Price}",
                        Location = new Point(10, 55),
                        AutoSize = true
                    };

                    Label lblMaterial = new Label
                    {
                        Text = $"Материал: {product.Material}",
                        Location = new Point(10, 75),
                        AutoSize = true
                    };

                    Label lblTime = new Label
                    {
                        Text = $"{time}",
                        Font = new Font("Segoe UI", 12, FontStyle.Bold),
                        ForeColor = Color.Red,
                        Location = new Point(350, 10),
                        AutoSize = true
                    };

                    card.Controls.Add(lblTitle);
                    card.Controls.Add(lblArt);
                    card.Controls.Add(lblPrice);
                    card.Controls.Add(lblMaterial);
                    card.Controls.Add(lblTime);

                    flowLayoutPanel1.Controls.Add(card);
                }
            }
        }

                    private int GetTimeForProduct(int quantity)
                    {
                        if (quantity <= 10000) return 0;
                        else if (quantity <= 50000) return 5;
                        else if (quantity <= 300000) return 10;
                        else return 15;
                    }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}